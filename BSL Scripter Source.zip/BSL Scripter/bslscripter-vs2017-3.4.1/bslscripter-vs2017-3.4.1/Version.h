#pragma once

#include "stdafx.h"

namespace Version
{
	const uint8_t MAJOR = 3;
	const uint8_t MINOR = 4;
	const uint8_t BUG = 0;
	const uint8_t BUILD = 1;
}